"""
Main entry point for LabelForge CLI.
"""

from .cli import main

if __name__ == "__main__":
    main()
